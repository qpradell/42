<form id="no" class="blog-search-home" method="get" action="<?php bloginfo('home') ?>">
	<input id="searchbox-home" name="s" type="text" value="où allez-vous?" onfocus="if (this.value == 'recherche') {this.value = '';}" onblur="if (this.value == '') {this.value = 'enter kewords';}" tabindex="1" />
	<input id="searchsubmit" class="button" type="submit" value="<?php _e( 'Ok', 'wpbx' ) ?>" />
</form>
