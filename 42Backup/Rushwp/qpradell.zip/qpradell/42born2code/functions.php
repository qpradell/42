<?php
add_action( 'init', 'create_post_type' );
function create_post_type() {
  register_post_type( 'produit',
    array(
      'labels' => array(
        'name' => __( 'Room' ),
        'singular_name' => __( 'Produit' )
      ),
      'public' => true,
			'supports' => array('title','editor','author','excerpt','comments','revisions'),
    )
  );
	register_taxonomy( 'location', 'produit', array( 'hierarchical' => false, 'label' => 'Location' ) );

			flush_rewrite_rules();
	}
add_action('add_meta_boxes','init_metabox');
function init_metabox(){
  add_meta_box('dispo_produit', 'Paramètres de location', 'dispo_produit', 'produit', 'side');
}
function check($cible,$test){
  if(in_array($test,$cible)){return ' checked="checked" ';}
}
function dispo_produit($post){
	$prix = get_post_meta($post->ID,'_prix',true);
	echo 'prix: '; echo $prix; echo '<br/>';
  $dispo = get_post_meta($post->ID,'_dispo_produit',true);
	echo 'type: '; echo $dispo; echo '<br/>';
	$cond = get_post_meta($post->ID,'_conditionnement_vin',false);
		echo 'equipements: '; echo $cond; echo '<br/>';
	echo'<hr/>';
	echo '<label for="prix">Prix par nuit </label>';
	echo '<input id="prix" type="text" name="prix" /><br/>';
  echo '<label for="dispo_meta">Type de propriété :</label>';
  echo '<select name="dispo_produit">';
  echo '<option ' . selected( 'maison', $dispo, false ) . ' value="maison">Maison</option>';
  echo '<option ' . selected( 'Appartement', $dispo, false ) . ' value="Appartement">Appartement</option>';
  echo '</select>';
	echo 'Equipements :<br/>';
	echo '<label><input type="checkbox" ' . check( $cond, 5 ) . ' name="cond[]" value="5" /> Cuisine</label>';
	echo '<label><input type="checkbox" ' . check( $cond, 35 ) . ' name="cond[]" value="35" /> Chauffage</label>';
	echo '<label><input type="checkbox" ' . check( $cond, 37 ) . ' name="cond[]" value="37" /> Internet</label>';
}
add_action('save_post','save_metabox');
function save_metabox($post_id){
	if(isset($_POST['dispo_produit']))
		update_post_meta($post_id, '_dispo_produit', $_POST['dispo_produit']);
		if(isset($_POST['prix']))
			update_post_meta($post_id, '_prix', $_POST['prix']);
  if(isset($_POST['cond'])){
    // je supprime toutes les entrées pour cette meta
    delete_post_meta($post_id, '_conditionnement_vin');
    // et pour chaque conditionnement coché, j'ajoute une metadonnée
    foreach($_POST['cond'] as $c){
      add_post_meta($post_id, '_conditionnement_vin', intval($c));
    }
  }
}
?>
<?php add_filter( 'pre_get_posts', 'my_get_posts' );
function my_get_posts( $query ) {
 if ( is_home() )
 $query->set( 'post_type', array( 'produit' ) );
 return $query;
}
?>
<?php
add_action( 'init', 'register_my_menus' );
function register_my_menus() {
	register_nav_menus(
		array(
			'primary-menu' => __( 'Main Menu' ),
			'another-menu' => __( 'Another Menu' ),
		));
}
add_theme_support( 'post-thumbnails' );
set_post_thumbnail_size( 200, 150, true ); // Normal post thumbnails

add_custom_background();

// Custom comment listing
function wpbx_comment($comment, $args, $depth) {
	$GLOBALS['comment'] = $comment;
	$commenter = get_comment_author_link();
	if ( ereg( '<a[^>]* class=[^>]+>', $commenter ) ) {
		$commenter = ereg_replace( '(<a[^>]* class=[\'"]?)', '\\1url ' , $commenter );
	} else {
		$commenter = ereg_replace( '(<a )/', '\\1class="url "' , $commenter );
	}
	$avatar_email = get_comment_author_email();
    $avatarURL = get_bloginfo('template_directory');
	$avatar = str_replace( "class='avatar", "class='avatar", get_avatar( $avatar_email, 40, $default = $avatarURL . '/images/gravatar-blank.jpg' ) );
?>
	<li <?php comment_class(); ?> id="comment-<?php comment_ID() ?>">
		<div id="div-comment-<?php comment_ID(); ?>">
			<div class="comment-author vcard">
				<?php echo $avatar . ' <span class="fn n">' . $commenter . '</span>'; ?>
			</div>
			<div class="comment-meta">
				<?php printf(__('%1$s <span class="meta-sep">|</span> <a href="%3$s" title="Permalink to this comment">Permalink</a>', 'wpbx'),
					get_comment_date('j M Y', '', '', false),
					get_comment_time(),
					'#comment-' . get_comment_ID() );
					edit_comment_link(__('Edit', 'wpbx'), ' <span class="meta-sep">|</span> <span class="edit-link">', '</span>');
				?>
				<span class="reply-link">
					<span class="meta-sep">|</span> <?php comment_reply_link(array_merge( $args, array('add_below' => 'div-comment', 'depth' => $depth, 'max_depth' => $args['max_depth']))) ?>
				</span>
			</div>

			<?php if ($comment->comment_approved == '0') _e("\t\t\t\t\t<span class='unapproved'>Your comment is awaiting moderation.</span>\n", 'wpbx') ?>

			<div class="comment-content"><?php comment_text() ?></div>
		</div>
<?php
}
// wpbx_comment()

// For category lists on category archives: Returns other categories except the current one (redundant)
function wpbx_cat_also_in($glue) {
	$current_cat = single_cat_title( '', false );
	$separator = "\n";
	$cats = explode( $separator, get_the_category_list($separator) );
	foreach ( $cats as $i => $str ) {
		if ( strstr( $str, ">$current_cat<" ) ) {
			unset($cats[$i]);
			break;
		}
	}
	if ( empty($cats) )
		return false;

	return trim(join( $glue, $cats ));
}

// For tag lists on tag archives: Returns other tags except the current one (redundant)
function wpbx_tag_also_in($glue) {
	$current_tag = single_tag_title( '', '',  false );
	$separator = "\n";
	$tags = explode( $separator, get_the_tag_list( "", "$separator", "" ) );
	foreach ( $tags as $i => $str ) {
		if ( strstr( $str, ">$current_tag<" ) ) {
			unset($tags[$i]);
			break;
		}
	}
	if ( empty($tags) )
		return false;

	return trim(join( $glue, $tags ));
}

// Generate custom excerpt length
function wpbx_excerpt_length($length) {
	return 75;
}
add_filter('excerpt_length', 'wpbx_excerpt_length');


// Widgets plugin: intializes the plugin after the widgets above have passed snuff
function wpbx_widgets_init() {
	if ( !function_exists('register_sidebars') ) {
		return;
	}
	register_sidebar( array(
'name' => 'Footer Sidebar 1',
'id' => 'footer-sidebar-1',
'description' => 'Appears in the footer area',
'before_widget' => '<aside id="%1$s" class="widget %2$s">',
'after_widget' => '</aside>',
'before_title' => '<h3 class="widget-title">',
'after_title' => '</h3>',
) );
register_sidebar( array(
'name' => 'Footer Sidebar 2',
'id' => 'footer-sidebar-2',
'description' => 'Appears in the footer area',
'before_widget' => '<aside id="%1$s" class="widget %2$s">',
'after_widget' => '</aside>',
'before_title' => '<h3 class="widget-title">',
'after_title' => '</h3>',
) );
register_sidebar( array(
'name' => 'Footer Sidebar 3',
'id' => 'footer-sidebar-3',
'description' => 'Appears in the footer area',
'before_widget' => '<aside id="%1$s" class="widget %2$s">',
'after_widget' => '</aside>',
'before_title' => '<h3 class="widget-title">',
'after_title' => '</h3>',
) );
	// Formats the theme widgets, adding readability-improving whitespace
	$p = array(
		'before_widget'  =>   '<li id="%1$s" class="widget %2$s">',
		'after_widget'   =>   "</li>\n",
		'before_title'   =>   '<h3 class="widget-title">',
		'after_title'    =>   "</h3>\n"
	);
	register_sidebars( 1, $p );
} // ici on ferme la fonction function wpbx_widgets_init()


// Runs our code at the end to check that everything needed has loaded
add_action( 'init', 'wpbx_widgets_init' );

// Adds filters for the description/meta content
add_filter( 'archive_meta', 'wptexturize' );
add_filter( 'archive_meta', 'convert_smilies' );
add_filter( 'archive_meta', 'convert_chars' );
add_filter( 'archive_meta', 'wpautop' );

// Translate, if applicable
load_theme_textdomain('wpbx');


// Construct the WordPress header
remove_action('wp_head', 'start_post_rel_link');
remove_action('wp_head', 'index_rel_link');
remove_action('wp_head', 'adjacent_posts_rel_link');
remove_action('wp_head', 'next_post_rel_link');
remove_action('wp_head', 'previous_post_rel_link');
?>
