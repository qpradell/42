<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes() ?>>
<head profile="http://gmpg.org/xfn/11">

<meta http-equiv="content-type" content="<?php bloginfo('html_type') ?>; charset=<?php bloginfo('charset') ?>" />
<meta name="description" content="" />
<meta name="keywords" content="" />
<title><?php wp_title( '-', true, 'right' ); echo wp_specialchars( get_bloginfo('name'), 1 ) ?></title>
<link rel="stylesheet" href="<?php bloginfo('stylesheet_directory'); ?>/style.css" type="text/css" media="screen" />

	<!--[if lte IE 6]><script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/supersleight-min.js"></script><![endif]-->
<?php wp_enqueue_script(get_bloginfo('template_directory').'/js/jquery.js'); ?>
<?php wp_enqueue_script('superfish', get_bloginfo('template_directory').'/js/superfish.js', array('jquery'), '1.7'); ?>
<?php wp_enqueue_script(get_bloginfo('template_directory').'/js/nav.js'); ?>
<?php if (trim(get_option('ft_header_code')) <> "") { echo stripslashes(get_option('ft_header_code')); } ?>
<?php if (is_singular()) wp_enqueue_script('comment-reply'); ?>

<?php wp_head(); ?> <!-- #NE PAS SUPPRIMER cf. codex wp_head() -->
</head>
<body <?php body_class() ?>>
<div id="top">
	<div class="pads clearfix"><?php wp_nav_menu( array( 'theme_location' => 'secondary-menu', 'sort_column' => 'menu_order', 'container_class' => 'nav' ) ); ?>
	</div>
</div>
<div id="header">
	<div class="pads clearfix">
		<?php
		if ( is_user_logged_in() ) {
    	echo '<a href="' . wp_logout_url( site_url( '/' ) ) .'">
				<button> se deconnecter </button>
			</a>';
		}
		else {
    	echo '<a href="wordpress/inscriptionconnexion/">
			<button> se connecter </button>
			</a>';
		}
?>
</div>
<a href="/wordpress/wp-admin/post-new.php?post_type=produit"><button> Publiez votre annonce </button></a>
		<a href="<?php echo get_option('home'); ?>">
			<img id="site-logo" src="<?php bloginfo('template_directory'); ?>/images/logo.jpeg" alt="<?php bloginfo('name'); ?>" />
		</a>
		<div id="blocsearch">
			<?php
			if(is_home() ){
		 	include('searchform-home.php');
		}
		else {
			include('searchform.php');
		}
?>
<?php wp_nav_menu( array( 'theme_location' => 'another-menu' ) ); ?>
		</div>
		<div class="nav-wrap">
		</div>
		<h1 style="text-align:center; margin-top:100px; margin-left: 100px;font-size: 30px;">Bienvenue a la maison</h1>
		<div style=" text-align:center;">
			<p style=" margin-left: -2000px; margin-right: -2000px; font-size:20px;"><a href="/wordpress/a-propos-de/"> mode d'emploi</a></p>
	</div>
	</div>
</div><!--  #header -->

<div id="container">
	<div class="pads clearfix">
