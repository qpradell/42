<?php get_header() ?>
  <div id="wrapper">
  	<div id="container">
  		<div id="contentfull">
  			<div class="entry-wide">
  				<h2> Juste pour le week-end!</h2>
  				<div class="entry-content">
  				<?php the_content() ?>
  				<a href="/wordpress/bruxelles/"><img class="img-index" src="<?php bloginfo('template_directory'); ?>/images/Brandenburg.jpg" alt="<?php bloginfo('name'); ?>" /></a>
  				<a href="/wordpress/londres/"><img class="img-index" src="<?php bloginfo('template_directory'); ?>/images/Eiffel.jpg" alt="<?php bloginfo('name'); ?>" /></a>
  				<a href="/wordpress/strasbourg/"><img class="img-index" src="<?php bloginfo('template_directory'); ?>/images/taiwan.jpg" alt="<?php bloginfo('name'); ?>" /></a>
  				</div>
  			</div><!-- entry -->
  <?php if ( get_post_custom_values('comments') ) comments_template() ?>

  		</div><!-- #contentfull -->
  	</div><!-- #container -->
  </div><!-- #wrapper -->
<?php get_footer() ?>
