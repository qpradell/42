<form id="no" class="blog-search" method="get" action="<?php bloginfo('home') ?>">
	<input id="searchbox" name="s" type="text" value="Où allez-vous?" onfocus="if (this.value == 'recherche') {this.value = '';}" onblur="if (this.value == '') {this.value = 'enter kewords';}" tabindex="1" />
	<input id="searchsubmit" class="button" type="submit" value="<?php _e( 'Ok', 'wpbx' ) ?>" />
</form>
